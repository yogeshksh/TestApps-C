export class Employee {
    public firstName: string;
    public lastName: string;
    public hireDate: Date;
}
