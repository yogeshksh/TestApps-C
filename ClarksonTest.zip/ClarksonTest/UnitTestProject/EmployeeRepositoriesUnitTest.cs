using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTestProject
{

    
    [TestClass]
    public class EmployeeRepositoriesUnitTest
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
